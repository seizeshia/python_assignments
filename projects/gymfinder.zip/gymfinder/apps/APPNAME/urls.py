from django.conf.urls import url
from django.contrib import admin
from . import views

urlpatterns = [
    url(r'^$', views.index),
    url(r'^register$', views.register),
    url(r'^login$', views.login),
    url(r'^users/(?P<user_id>\d+)$', views.show_user),
    url(r'^messageboard/$', views.messageboard),
    url(r'^messageboard/message/add_message$', views.new_message_process),
    url(r'^messageboard/message/(?P<message_id>\d+)/like$', views.like_message),
    url(r'^messageboard/message/(?P<message_id>\d+)/unlike$', views.unlike_message),
    url(r'^messageboard/message/(?P<message_id>\d+)/add_comment$', views.new_comment_process),
    url(r'^meetups$', views.meetups),
    url(r'^meetups/new$', views.new_meetup),
    url(r'^meetups/new/process$', views.new_meetup_process),
    url(r'^meetups/(?P<meetup_id>\d+)$', views.show_meetup),
    url(r'^meetups/search$', views.search_meetup),
    url(r'^deals$', views.deals),
    url(r'^logout$', views.logout),
    url(r'^home/message/(?P<message_id>\d+)/like$', views.home_like_message),
    url(r'^home/message/(?P<message_id>\d+)/unlike$', views.home_unlike_message),
    url(r'^landing$',views.landing),
    url(r'^form$',views.form),
    url(r'^createdeal$', views.createdeal),
    url(r'^getting$',views.getting),
    # url(r'^callingapi$', views.callingapi),
]
