# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.apps import AppConfig

import request-cache


class AppnameConfig(AppConfig):
    name = 'APPNAME'

    install_cache(){
    requests_cache.install_cache(cache_name='github_cache', backend='sqlite', expire_after=10000000)
    }
