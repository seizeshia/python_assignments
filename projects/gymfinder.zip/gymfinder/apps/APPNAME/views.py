# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.shortcuts import render, redirect, HttpResponse
from django.contrib import messages
from .models import User, UserManager, Messageboard_Message, Messageboard_Message_Like, Messageboard_Comment, Messageboard_Comment_Like, MessageboardManager, Meetup, MeetupManager
import datetime
import random
import rauth
import requests
import json
from yelp.client import Client
from yelp.oauth1_authenticator import Oauth1Authenticator


# Create your views here.
def index(request):
    allmeetups= Meetup.objects.all()
    meetupname=[]
    newmeetups=[]

    for meetup in allmeetups:
        meetupname.append(meetup)

    random.shuffle(meetupname)
    # try:
    # this_user=User.objects.get(id=request.session['user_id'])

    messages_list=[]
    comments_list=[]
    likes_list=[]
    for message in Messageboard_Message.objects.all().order_by('-created_at'):
        messages_list.append(message)
    for comment in Messageboard_Comment.objects.all():
        comments_list.append(comment)
    for like in Messageboard_Message_Like.objects.all():
        likes_list.append(like)

    data={
    "meetups":meetupname,
    # "this_user":this_user,
    "messages_list":messages_list,
    "comments_list":comments_list,
    "likes_list":likes_list,
    }


    if 'user_id' not in request.session:
        return render(request, 'APPNAME/index.html')
    else:
        return render(request, 'APPNAME/home.html',data)

def register(request):
    data = {
    'first_name':request.POST['reg_first_name'],
    'last_name':request.POST['reg_last_name'],
    'username':request.POST['reg_username'],
    'password':request.POST['reg_password'],
    'confirm_password':request.POST['reg_confirm_password'],
    }
    new_user = User.objects.register(data)
    if new_user['errors_list']:
        for error in new_user['errors_list']:
            messages.add_message(request, messages.ERROR, error)
        return redirect('/')
    else:
        messages.add_message(request, messages.ERROR, "Successfully Registered!")
        return redirect('/')

def login(request):
    data = {
    'username':request.POST['login_username'],
    'password':request.POST['login_password'],
    }
    user = User.objects.login(data)
    if user['errors_list']:
        for error in user['errors_list']:
            messages.add_message(request, messages.ERROR, error)
        return redirect('/')
    else:
        request.session['user_id']=user['logged_user'].id
        request.session['first_name']=user['logged_user'].first_name
        request.session['last_name']=user['logged_user'].last_name
        return redirect('/')

def show_user(request, user_id):
    this_user = User.objects.get(id=user_id)
    data = {
    'this_user':this_user,
    }
    return render(request, 'APPNAME/show_user.html', data)

def messageboard(request):
    this_user=User.objects.get(id=request.session['user_id'])
    messages_list=[]
    comments_list=[]
    likes_list=[]
    for message in Messageboard_Message.objects.all().order_by('-created_at'):
        messages_list.append(message)
    for comment in Messageboard_Comment.objects.all():
        comments_list.append(comment)
    for like in Messageboard_Message_Like.objects.all():
        likes_list.append(like)
    data = {
    "this_user":this_user,
    "messages_list":messages_list,
    "comments_list":comments_list,
    "likes_list":likes_list,
    }
    return render(request, 'APPNAME/messageboard.html', data);


def new_message_process(request):
    this_user = User.objects.get(id=request.session['user_id'])
    data = {
    'message':request.POST['message'],
    'this_user':this_user,
    }
    new_message=Messageboard_Message.objects.message(data)
    if new_message['errors_list']:
        for error in new_message['errors_list']:
            messages.add_message(request, messages.ERROR, error)
        return redirect('/messageboard')
    else:
        messages.add_message(request, messages.ERROR, "Posted!")
        return redirect('/messageboard')

def like_message(request, message_id):
    this_user=User.objects.get(id=request.session['user_id'])
    this_message=Messageboard_Message.objects.get(id=message_id)
    try:
        Messageboard_Message_Like.objects.get(messageboard_message=this_message, user=this_user)
        messages.add_message(request, messages.ERROR, "INVALID APPROACH")
    except:
        Messageboard_Message_Like.objects.create(messageboard_message=this_message, user=this_user)
    return redirect('/messageboard')

def unlike_message(request, message_id):
    this_user=User.objects.get(id=request.session['user_id'])
    this_message=Messageboard_Message.objects.get(id=message_id)
    try:
        Messageboard_Message_Like.objects.get(messageboard_message=this_message, user=this_user).delete()
    except:
        messages.add_message(request, messages.ERROR, "INVALID APPROACH")
    return redirect('/messageboard')

def home_like_message(request, message_id):
    this_user=User.objects.get(id=request.session['user_id'])
    this_message=Messageboard_Message.objects.get(id=message_id)
    try:
        Messageboard_Message_Like.objects.get(messageboard_message=this_message, user=this_user)
        messages.add_message(request, messages.ERROR, "INVALID APPROACH")
    except:
        Messageboard_Message_Like.objects.create(messageboard_message=this_message, user=this_user)
    return redirect('/')

def home_unlike_message(request, message_id):
    this_user=User.objects.get(id=request.session['user_id'])
    this_message=Messageboard_Message.objects.get(id=message_id)
    try:
        Messageboard_Message_Like.objects.get(messageboard_message=this_message, user=this_user).delete()
    except:
        messages.add_message(request, messages.ERROR, "INVALID APPROACH")
    return redirect('/')

def new_comment_process(request, message_id):
    this_user = User.objects.get(id=request.session['user_id'])
    this_message = Messageboard_Message.objects.get(id=message_id)
    data = {
    'comment':request.POST['comment'],
    'this_user':this_user,
    'this_message':this_message,
    }
    new_comment=Messageboard_Comment.objects.comment(data)
    if new_comment['errors_list']:
        for error in new_comment['errors_list']:
            messages.add_message(request, messages.ERROR, error)
        return redirect('/messageboard')
    else:
        messages.add_message(request, messages.ERROR, "Commented!")
        return redirect('/messageboard')

def meetups(request):
    meetups_list=[]
    for meetup in Meetup.objects.all():
        meetups_list.append(meetup)

    data={
    "meetups_list":meetups_list,
    }
    return render(request, 'APPNAME/meetups.html', data)

def new_meetup(request):
    return render(request, 'APPNAME/new_meetup.html')

def new_meetup_process(request):
    this_user = User.objects.get(id=request.session['user_id'])
    data={
    'eventname':request.POST['eventname'],
    'location':request.POST['location'],
    'description':request.POST['description'],
    'date':request.POST['date'],
    'details':request.POST['details'],
    'this_user':this_user,
    }

    new_meetup=Meetup.objects.add(data)
    if new_meetup['errors_list']:
        for error in new_meetup['errors_list']:
            messages.add_message(request, messages.ERROR, error)
        return redirect('/meetups/new')
    else:
        messages.add_message(request, messages.ERROR, "Posted!")
        return redirect('/meetups')


def show_meetup(request, meetup_id):
    this_meetup = Meetup.objects.get(id=meetup_id)
    data={
    'this_meetup':this_meetup,
    }
    return render(request, 'APPNAME/show_meetup.html', data)


def search_meetup(request):
    if request.method == 'GET':
        search_query = request.GET.get('search_box', None)
        print search_query
        search_list=[]
        for meetup in Meetup.objects.filter(eventname__contains=search_query):
            search_list.append(meetup)
        data={
        'search_list':search_list,
        }
        return render(request, 'APPNAME/search_meetup.html', data)



def deals(request):
    return render(request, 'APPNAME/deals.html')

def logout(request):
    request.session.clear()
    return redirect('/')

def landing(request):
    return render(request, 'APPNAME/landing.html')

def createdeal(request):
    return render(request, 'APPNAME/createdeal.html')
def getting(request):
    r = requests.post('https://api.yelp.com/oauth2/token', data={'grant_type':"client_credentials", "client_id":"YFwchaLGlVSnFPeQXIEvjQ","client_secret":"RoVIIt9dAifYUKD1a8GyIMwKdzqGHrHqHsiACGh5BLEwuMa2xLo4hYvEoB2rdtfG"})

    tokendata = json.loads(r.text)
    print(tokendata, "**************")
    print (tokendata)
    accesstoken = tokendata["access_token"]
    accesstype = tokendata['token_type']
    expires = tokendata['expires_in']
    keyword = request.POST['keyword']
    location = request.POST['location']



    url_params={
    'term':keyword,
    "location":location
    }

    variable1 = requests.get('https://api.yelp.com/v3/businesses/search', headers={'Authorization': 'Bearer %s' % accesstoken}, params=url_params)
    print type(variable1.text)
    response_data=json.loads(variable1.text)
    print response_data
    for business in response_data['businesses']:
        print business['name']

    data={
    "thedata":response_data
    }


    return render(request, 'APPNAME/createdeal.html', data)

def form(request):
    return render(request, 'APPNAME/createdeal.html')
